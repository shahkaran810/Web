## POC Admin App (https://md-poc-e83db.web.app)
## Getting started

- Recommended `node js 14+` and `npm 6+`
- Install dependencies: `yarn install`
- Start the server:  `yarn start`

## Contact us

Email Us: contact@mdtechcs.com
