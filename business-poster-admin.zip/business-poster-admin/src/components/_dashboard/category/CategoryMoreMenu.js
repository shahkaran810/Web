import { Icon } from "@iconify/react";
import { useRef, useState } from "react";
import editFill from "@iconify/icons-eva/edit-fill";
import { Link as RouterLink, useNavigate } from "react-router-dom";
import trash2Outline from "@iconify/icons-eva/trash-2-outline";
import moreVerticalFill from "@iconify/icons-eva/more-vertical-fill";
// material
import {
  Menu,
  MenuItem,
  IconButton,
  ListItemIcon,
  ListItemText,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  DialogActions,
  DialogContentText,
} from "@material-ui/core";
import { deleteDoc, doc, updateDoc } from "@firebase/firestore";
import { db } from "../../../../src/index";
import { LoadingButton } from "@material-ui/lab";

// ----------------------------------------------------------------------
export default function CategoryMoreMenu(props) {
  const ref = useRef(null);
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [categoryName, setCategoryName] = useState("");
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [categoryTypeName] = useState(props.categoryTypeName);
  const [categoryID] = useState(props.categoryID);

  const handleClickOpen = () => {
    setIsOpen(false);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleOpenDeleteDialog = () => {
    setIsOpen(false);
    setOpenDeleteDialog(true);
  };

  const handleDeleteDialogClose = () => {
    setOpenDeleteDialog(false);
  };

  const handleDelete = () => {
    deleteDoc(doc(db, "imageCategoryType", categoryID)).then(() => {
      // console.log("Deleted Succussful");
      props.setUpdateCategoryLoading();
    });
    handleDeleteDialogClose();
  };

  const handleChange = (event) => {
    setCategoryName(event.target.value);
  };

  const handleUpdate = async () => {
    const categoryUpdateRef = doc(db, "imageCategoryType", categoryID);

    await updateDoc(categoryUpdateRef, {
      imgCatTypeName: categoryName,
    });
    // console.log("Update Succussful");
    handleClose();
    props.setUpdateCategoryLoading();
  };

  return (
    <>
      <IconButton ref={ref} onClick={() => setIsOpen(true)}>
        <Icon icon={moreVerticalFill} width={20} height={20} />
      </IconButton>

      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="form-dialog-title"
      >
        <DialogTitle id="form-dialog-title">Edit Category</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            id="name"
            label="Category Name"
            defaultValue={categoryTypeName}
            fullWidth
            onChange={handleChange}
          />
        </DialogContent>
        <DialogActions>
          <LoadingButton onClick={handleClose} color="primary">
            Cancel
          </LoadingButton>
          <LoadingButton onClick={handleUpdate} color="primary">
            Update
          </LoadingButton>
        </DialogActions>
      </Dialog>

      <Dialog
        open={openDeleteDialog}
        keepMounted
        onClose={handleDeleteDialogClose}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle id="alert-dialog-slide-title">{"Delete?"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
            Are you sure you want to delete?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <LoadingButton onClick={handleDeleteDialogClose} color="primary">
            No
          </LoadingButton>
          <LoadingButton onClick={handleDelete} color="primary">
            Yes
          </LoadingButton>
        </DialogActions>
      </Dialog>

      <Menu
        open={isOpen}
        anchorEl={ref.current}
        onClose={() => setIsOpen(false)}
        PaperProps={{
          sx: { width: 200, maxWidth: "100%" },
        }}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
        transformOrigin={{ vertical: "top", horizontal: "right" }}
      >
        <MenuItem sx={{ color: "text.secondary" }}>
          <ListItemIcon>
            <Icon icon={trash2Outline} width={24} height={24} />
          </ListItemIcon>
          <ListItemText
            primary="Delete"
            primaryTypographyProps={{ variant: "body2" }}
            onClick={handleOpenDeleteDialog}
          />
        </MenuItem>
        <MenuItem sx={{ color: "text.secondary" }}>
          <ListItemIcon>
            <Icon icon={editFill} width={24} height={24} />
          </ListItemIcon>
          <ListItemText
            primary="Edit"
            primaryTypographyProps={{ variant: "body2" }}
            onClick={handleClickOpen}
          />
        </MenuItem>
      </Menu>
    </>
  );
}
