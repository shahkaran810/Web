import * as Yup from "yup";
import { useState } from "react";
import { useFormik, Form, FormikProvider } from "formik";
// material
import { Stack, TextField } from "@material-ui/core";
import { LoadingButton } from "@material-ui/lab";
import { addDoc, collection, updateDoc, doc } from "firebase/firestore";
import { db } from "../../../../src/index";

export default function AddNewCategory() {
  const [isSubmitting, setSubmitting] = useState(false);

  const AddCategorySchema = Yup.object().shape({
    categoryName: Yup.string()
      .min(2, "Too Short!")
      .max(50, "Too Long!")
      .required("Category Name required"),
  });

  const formik = useFormik({
    initialValues: {
      categoryName: "",
    },
    validationSchema: AddCategorySchema,
    onSubmit: async (values) => {
      setSubmitting(true);
      let { categoryName } = values;
      const docRef = await addDoc(collection(db, "imageCategoryType"), {
        imgCatTypeName: categoryName,
      });
      // console.log("Document ID: ", docRef.id);
      const UpdateRef = doc(db, "imageCategoryType", docRef.id);

      await updateDoc(UpdateRef, {
        imgCatTypeId: docRef.id,
        imgCatTypeName: categoryName,
      });
      setSubmitting(false);
    },
  });

  const { errors, touched, values, handleSubmit, getFieldProps } = formik;

  return (
    <FormikProvider value={formik}>
      <Form autoComplete="off" noValidate onSubmit={handleSubmit}>
        <Stack spacing={3}>
          <TextField
            fullWidth
            label="Category Name"
            {...getFieldProps("categoryName")}
            error={Boolean(touched.categoryName && errors.categoryName)}
            helperText={touched.categoryName && errors.categoryName}
          />
        </Stack>
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          sx={{ my: 2 }}
        ></Stack>

        <LoadingButton
          fullWidth
          size="large"
          type="submit"
          variant="contained"
          loading={isSubmitting}
        >
          Add New Category
        </LoadingButton>
      </Form>
    </FormikProvider>
  );
}
