import { Icon } from "@iconify/react";
import { useEffect, useRef, useState } from "react";
import { Link as RouterLink, useNavigate } from "react-router-dom";
import trash2Outline from "@iconify/icons-eva/trash-2-outline";
// material
import {
  IconButton,
  DialogTitle,
  Dialog,
  DialogContent,
  DialogContentText,
  DialogActions,
  Grid,
  TableCell,
} from "@material-ui/core";
import { LoadingButton } from "@material-ui/lab";
import { db } from "src";
import {
  doc,
  updateDoc,
  arrayRemove,
  collection,
  getDocs,
  getDoc,
  onSnapshot,
} from "firebase/firestore";
import { useAlert } from "react-alert";

export default function DeleteImage({
  DeleteImageUrl,
  DeleteDocID,
  getNewURL,
}) {
  const ref = useRef(null);
  const alert = useAlert();
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [newImageUrl, setNewImageUrl] = useState([]);

  const handleOpenDeleteDialog = () => {
    setOpenDeleteDialog(true);
  };
  const handleDeleteDialogClose = () => {
    setOpenDeleteDialog(false);
  };
  const handleDelete = async () => {
    const docRef = doc(db, "layout_category", DeleteDocID);

    await updateDoc(docRef, {
      layoutImages: arrayRemove(...[{ image: { uri: DeleteImageUrl } }]),
    });
    if ("caches" in window) {
      caches.keys().then((names) => {
        names.forEach((name) => {
          caches.delete(name);
        });
      });
    }

    const unsub = onSnapshot(doc(db, "layout_category", DeleteDocID), (doc) => {
      setNewImageUrl(getNewURL(...doc.data().layoutImages));
    });
    setOpenDeleteDialog(false);
    alert.success("Image Deleted!");
  };

  return (
    <>
      <Dialog
        open={openDeleteDialog}
        keepMounted
        onClose={handleDeleteDialogClose}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle id="alert-dialog-slide-title">{"Delete?"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
            Are you sure you want to delete?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <LoadingButton onClick={handleDeleteDialogClose} color="primary">
            No
          </LoadingButton>
          <LoadingButton onClick={handleDelete} color="primary">
            Yes
          </LoadingButton>
        </DialogActions>
      </Dialog>
      <Grid>
        <IconButton
          ref={ref}
          onClick={handleOpenDeleteDialog}
          sx={{ width: "180%" }}
        >
          <Icon icon={trash2Outline} height={20} />
        </IconButton>
      </Grid>
    </>
  );
}
