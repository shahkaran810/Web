import PropTypes from "prop-types";
// material
import {
  Box,
  Card,
  Link,
  TableRow,
  Grid,
  CircularProgress,
} from "@material-ui/core";
import { styled } from "@material-ui/core/styles";
import DeleteImage from "./DeleteImage";
import { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/styles";

const ProductImgStyle = styled("img")({
  top: 0,
  width: "100%",
  height: "100%",
  objectFit: "cover",
  position: "absolute",
});

ImageCard.propTypes = {
  Images: PropTypes.object,
};

export default function ImageCard({ Images, DocID, getNewURL }) {
  return (
    <Card>
      <DeleteImage
        DeleteImageUrl={Images}
        DeleteDocID={DocID}
        getNewURL={getNewURL}
      />
      <Box sx={{ pt: "100%", position: "relative" }}>
        <ProductImgStyle src={Images} />
      </Box>
    </Card>
  );
}
