import { Icon } from "@iconify/react";
import { useCallback, useEffect, useRef, useState } from "react";
import editFill from "@iconify/icons-eva/edit-fill";
import {
  Link as RouterLink,
  Navigate,
  Route,
  Routes,
  useNavigate,
} from "react-router-dom";
import trash2Outline from "@iconify/icons-eva/trash-2-outline";
import moreVerticalFill from "@iconify/icons-eva/more-vertical-fill";
// material
import {
  Menu,
  MenuItem,
  IconButton,
  ListItemIcon,
  ListItemText,
  DialogTitle,
  Dialog,
  DialogContent,
  DialogContentText,
  DialogActions,
  CircularProgress,
  Grid,
  Stack,
  Typography,
  Container,
  Button,
  TextField,
  FormControl,
  InputLabel,
  Select,
  TableBody,
  TableRow,
  TableCell,
} from "@material-ui/core";
import { LoadingButton } from "@material-ui/lab";
import { db } from "src";
import {
  deleteDoc,
  doc,
  updateDoc,
  arrayUnion,
  collection,
  getDocs,
} from "@firebase/firestore";
import LayoutCatedoryUploadImg from "../../../pages/LayoutCategoryUploadImg";
import DashboardLayout from "src/layouts/dashboard";
import { LayoutCategoryImageList } from ".";
import plusFill from "@iconify/icons-eva/plus-fill";
import {
  getStorage,
  ref as storageRef,
  getDownloadURL,
  uploadBytesResumable,
} from "firebase/storage";
import { makeStyles } from "@material-ui/styles";
import Page from "src/components/Page";
import { useAlert } from "react-alert";

export default function LayoutCategoryMoreMenu(props) {
  const ref = useRef(null);
  const alert = useAlert();
  const [isOpenMenu, setIsOpen] = useState(false);
  const [isOpen, setOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [categoryImgKey] = useState(props.categoryImgKey);
  const [layoutImages] = useState(props.layoutImages);
  const [categoryTypeName] = useState(props.getCategoryType);
  const [categoryType, setCategoryType] = useState("");
  const [imgCategory] = useState(props.getImageCategory);
  const [imgCategoryName, setImgCategoryName] = useState("");
  const [title] = useState(props.title);
  const [updatedtitle, setTitle] = useState("");
  const [isSubmitting, setSubmitting] = useState(false);

  const useStylesLoading = makeStyles(() => ({
    root: {
      position: "relative",
    },
    top: {
      color: "#007B55",
      animationDuration: "550ms",
      position: "absolute",
      marginLeft: "-10%",
      marginTop: "-4%",
    },
    circle: {
      strokeLinecap: "round",
    },
  }));

  const classes = useStylesLoading();

  const navigate = useNavigate();

  const Title = (text) => {
    setTitle(text.target.value);
  };

  const handleImageCategory = (event) => {
    setImgCategoryName(event.target.value);
  };

  const handleChangeCategoryType = (event) => {
    setCategoryType(event.target.value);
    console.log("Value:", event.target.value);
  };

  const handleEditDialogOpen = () => {
    setEditOpen(true);
    setIsOpen(false);
  };

  const handleEditDialogClose = () => {
    setEditOpen(false);
  };

  const handleOpenDeleteDialog = () => {
    setOpen(false);
    setOpenDeleteDialog(true);
    setIsOpen(false);
  };
  const handleDeleteDialogClose = () => {
    setOpenDeleteDialog(false);
  };
  const handleDelete = () => {
    deleteDoc(doc(db, "layout_category", categoryImgKey)).then(() => {
      alert.success("Category Deleted!");
    });
    handleDeleteDialogClose();
    props.setUpdateLoading();
  };

  const handleUpdate = async () => {
    setSubmitting(true);
    const UpdateRef = doc(db, "layout_category", categoryImgKey);

    await updateDoc(UpdateRef, {
      category: categoryType.imgCatTypeName,
      title: updatedtitle,
      imgCatId: imgCategoryName.key,
      imgCatTypeId: categoryType.key,
      imageCategoryName: imgCategoryName.imgCatName,
    });
    handleEditDialogClose();
    setSubmitting(false);
    props.setUpdateLoading();
  };

  return (
    <>
      <Dialog
        open={openDeleteDialog}
        keepMounted
        onClose={handleDeleteDialogClose}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle id="alert-dialog-slide-title">{"Delete?"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
            Are you sure you want to delete?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <LoadingButton onClick={handleDeleteDialogClose} color="primary">
            No
          </LoadingButton>
          <LoadingButton onClick={handleDelete} color="primary">
            Yes
          </LoadingButton>
        </DialogActions>
      </Dialog>

      <Dialog
        open={editOpen}
        onClose={handleEditDialogClose}
        aria-labelledby="form-dialog-title"
      >
        <DialogTitle id="form-dialog-title">Edit Sub Category</DialogTitle>
        <DialogContent>
          <Stack spacing={3}>
            <TextField
              fullWidth
              margin="dense"
              label="Title"
              defaultValue={title}
              onChange={Title}
            />
            <FormControl sx={{ minWidth: 250 }}>
              <InputLabel id="demo-simple-select-autowidth-label">
                Select Sub Category Type
              </InputLabel>
              <Select
                labelId="demo-simple-select-autowidth-label"
                id="demo-simple-select-autowidth"
                value={categoryType}
                onChange={handleChangeCategoryType}
                autoWidth
                label="Select sub Category Type"
              >
                {categoryTypeName.map((name) => (
                  <MenuItem key={name.key} value={name}>
                    {name.imgCatTypeName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl sx={{ minWidth: 250 }}>
              <InputLabel id="demo-simple-select-autowidth-label">
                Select Sub Category Name
              </InputLabel>
              <Select
                labelId="demo-simple-select-autowidth-label"
                id="demo-simple-select-autowidth"
                value={imgCategoryName}
                onChange={handleImageCategory}
                autoWidth
                label="Select Sub Category Name"
              >
                {imgCategory.map((name) => (
                  <MenuItem key={name.key} value={name}>
                    {name.imgCatName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Stack>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            sx={{ my: 2 }}
          ></Stack>

          <Button
            fullWidth
            size="large"
            type="submit"
            variant="contained"
            // loading={isSubmitting}
            disabled={isSubmitting}
            onClick={handleUpdate}
          >
            {isSubmitting && (
              <i>
                <CircularProgress
                  variant="indeterminate"
                  disableShrink
                  className={classes.top}
                  classes={{
                    circle: classes.circle,
                  }}
                  size={20}
                  thickness={4}
                />
              </i>
            )}
            Update
          </Button>
        </DialogContent>
      </Dialog>

      <IconButton ref={ref} onClick={() => setIsOpen(true)}>
        <Icon icon={moreVerticalFill} width={20} height={20} />
      </IconButton>
      <Menu
        open={isOpenMenu}
        anchorEl={ref.current}
        onClose={() => setIsOpen(false)}
        PaperProps={{
          sx: { width: 200, maxWidth: "100%" },
        }}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
        transformOrigin={{ vertical: "top", horizontal: "right" }}
      >
        <MenuItem sx={{ color: "text.secondary" }}>
          <ListItemIcon>
            <Icon icon={editFill} width={24} height={24} />
          </ListItemIcon>
          <ListItemText
            primary="Edit"
            primaryTypographyProps={{ variant: "body2" }}
            onClick={handleEditDialogOpen}
          />
        </MenuItem>
        <MenuItem sx={{ color: "text.secondary" }}>
          <ListItemIcon>
            <Icon icon={trash2Outline} width={24} height={24} />
          </ListItemIcon>
          <ListItemText
            primary="Delete"
            primaryTypographyProps={{ variant: "body2" }}
            onClick={handleOpenDeleteDialog}
          />
        </MenuItem>
        <MenuItem sx={{ color: "text.secondary" }}>
          <ListItemIcon>
            <Icon icon={editFill} width={24} height={24} />
          </ListItemIcon>
          <ListItemText
            primary="View"
            primaryTypographyProps={{ variant: "body2" }}
            onClick={() =>
              // update: () => props.setUpdateLoading(),
              navigate("/dashboard/layoutCategory", {
                state: {
                  id: categoryImgKey,
                  img: layoutImages,
                },
              })
            }
          />
        </MenuItem>
      </Menu>
    </>
  );
}
