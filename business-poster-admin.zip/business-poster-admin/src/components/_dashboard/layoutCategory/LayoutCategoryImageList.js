import { Stack } from "@material-ui/core";
import React, { useEffect, useState } from "react";
import ImageCard from "./ImageCard";

const LayoutCategoryImageList = (props) => {
  return (
    <Stack marginTop={3}>
      <ImageCard
        Images={props.ImageUri}
        DocID={props.docID}
        getNewURL={props.getNewURL}
      />
    </Stack>
  );
};
export default LayoutCategoryImageList;
