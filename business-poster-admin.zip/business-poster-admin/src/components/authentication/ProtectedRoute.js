import React, { createElement, useState } from "react";
import { Route, Link, Navigate } from "react-router-dom";
import Login from "src/pages/Login";

const ProtectedRoute = ({ component, ...rest }) => {
  const [isAuth] = useState(false);

  return (
    <Route
      {...rest}
      render={(props) =>
        isAuth ? (
          createElement(component, props)
        ) : (
          // <Navigate to="/login" replace />
          <Link to="/login" />
        )
      }
    />
  );
};

export default ProtectedRoute;
