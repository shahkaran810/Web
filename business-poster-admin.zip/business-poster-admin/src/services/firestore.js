import { addDoc, collection } from "firebase/firestore";
import { db } from "../../src/index";

export default class FireStore {
  static addAdminUser = async (userDetails, uid, callback) => {
    try {
      await addDoc(collection(db, "adminUsers"), userDetails);
    } catch (e) {
      console.error("Error adding user: ", e);
    }
  };
}
