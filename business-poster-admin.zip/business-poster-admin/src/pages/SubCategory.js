import { filter } from "lodash";
import { Icon } from "@iconify/react";
import { useEffect, useState } from "react";
import plusFill from "@iconify/icons-eva/plus-fill";
import { Link as RouterLink } from "react-router-dom";
// material
import {
  Card,
  Table,
  Stack,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
  TablePagination,
  CircularProgress,
  Button,
  Dialog,
  DialogTitle,
  TextField,
  DialogContent,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@material-ui/core";
// components
import Page from "../components/Page";
import Scrollbar from "../components/Scrollbar";
import { UserListHead, UserListToolbar } from "../components/_dashboard/user";
import { LayoutCategoryMoreMenu } from "../components/_dashboard/layoutCategory";
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  doc,
  arrayUnion,
  Timestamp,
} from "firebase/firestore";
import {
  getStorage,
  ref as storageRef,
  getDownloadURL,
  uploadBytesResumable,
} from "firebase/storage";
import { db } from "../index";
import { makeStyles } from "@material-ui/styles";

const TABLE_HEAD = [
  { id: "subCatTypr", label: "Sub Category Type", alignRight: false },
  { id: "subCategoryName", label: "Sub Category Name", alignRight: false },
  // { id: "imgCatId", label: "Sub Category ID", alignRight: false },
  // { id: "imgCatTypeId", label: "Image Category Type Id", alignRight: false },
  { id: "" },
];

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}
function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return filter(
      array,
      (_user) => _user.name.toLowerCase().indexOf(query.toLowerCase()) !== -1
    );
  }
  return stabilizedThis.map((el) => el[0]);
}

export default function SubCategory() {
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState("asc");
  const [selected, setSelected] = useState([]);
  const [orderBy, setOrderBy] = useState("name");
  const [filterName, setFilterName] = useState("");
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [loading, setLoading] = useState(false);
  const [isSubmitting, setSubmitting] = useState(false);
  const [type, setType] = useState("");
  const [imgCatName, setImgCatName] = useState("");
  const [openSubCategoryDialog, setOpenSubCategoryDialog] = useState(false);
  const [imgCategory, setImgCategory] = useState([]);
  const [imgCategoryType, setImgCategoryType] = useState([]);
  const [imgCatTypeId, setImgCatTypeId] = useState("");

  const useStylesLoading = makeStyles(() => ({
    root: {
      position: "relative",
    },
    top: {
      color: "#007B55",
      animationDuration: "550ms",
      position: "absolute",
      marginLeft: "45%",
    },
    circle: {
      strokeLinecap: "round",
    },
  }));

  const classes = useStylesLoading();

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (event) => {
    setFilterName(event.target.value);
  };
  const handleImgCategoryId = (event) => {
    setImgCatTypeId(event.target.value);
  };
  const Type = (text) => {
    setType(text.target.value);
  };
  const ImageCategoryName = (text) => {
    setImgCatName(text.target.value);
  };
  const SubCategoryDialog = () => {
    setOpenSubCategoryDialog(true);
  };
  const SubCategoryDialogClose = () => {
    setOpenSubCategoryDialog(false);
  };

  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - imgCategory.length) : 0;

  const filteredImgCategoryLists = applySortFilter(
    imgCategory,
    getComparator(order, orderBy),
    filterName
  );

  const isUserNotFound = filteredImgCategoryLists.length === 0;

  const getImageCategory = () => {
    const categoryImgCategoryCol = collection(db, "imageCategory");
    const snapshot = getDocs(categoryImgCategoryCol)
      .then((snapshot) => {
        const imgCategory = [];
        snapshot.forEach((doc) => {
          imgCategory.push({
            key: doc.id,
            ...doc.data(),
          });
        });
        setImgCategory(imgCategory);
        setLoading(true);
      })
      .catch((error) => console.log(error));
  };
  const getImageCategoryType = () => {
    const categoryImgCategoryCol = collection(db, "imageCategoryType");
    const snapshot = getDocs(categoryImgCategoryCol)
      .then((snapshot) => {
        const imgCategoryType = [];
        snapshot.forEach((doc) => {
          imgCategoryType.push({
            key: doc.id,
            ...doc.data(),
          });
        });
        setImgCategoryType(imgCategoryType);
        setLoading(true);
      })
      .catch((error) => console.log(error));
  };

  const AddSubCategoryImage = async (url) => {
    setSubmitting(true);
    const docRef = await addDoc(collection(db, "imageCategory"), {
      type: type,
      imgCatTypeId: imgCatTypeId,
      imgCatName: imgCatName,
    });
    console.log("Doc ID:", docRef.id);
    const UpdateRef = doc(db, "imageCategory", docRef.id);

    await updateDoc(UpdateRef, {
      imgCatId: docRef.id,
    });

    setLoading(true);
    getImageCategory();
    SubCategoryDialogClose();
    setLoading(false);
  };

  useEffect(() => {
    getImageCategory();
    getImageCategoryType();
  }, []);

  return (
    <>
      <Dialog
        open={openSubCategoryDialog}
        onClose={SubCategoryDialogClose}
        aria-labelledby="form-dialog-title"
      >
        <DialogTitle id="form-dialog-title">Add Sub Category</DialogTitle>
        <DialogContent>
          <Stack spacing={3}>
            <TextField
              fullWidth
              margin="dense"
              label="Type"
              value={type}
              onChange={Type}
            />
            <TextField
              fullWidth
              margin="dense"
              label="Image Category Name"
              value={imgCatName}
              onChange={ImageCategoryName}
            />
            <FormControl sx={{ minWidth: 200 }}>
              <InputLabel id="demo-simple-select-autowidth-label">
                Image Category Type
              </InputLabel>
              <Select
                labelId="demo-simple-select-autowidth-label"
                id="demo-simple-select-autowidth"
                value={imgCatTypeId}
                onChange={handleImgCategoryId}
                autoWidth
                label="Image Category Type"
              >
                {imgCategoryType.map((name) => (
                  <MenuItem key={name.key} value={name.key}>
                    {name.imgCatTypeName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Stack>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            sx={{ my: 2 }}
          ></Stack>

          <Button
            fullWidth
            size="large"
            type="submit"
            variant="contained"
            loading={isSubmitting}
            onClick={AddSubCategoryImage}
          >
            Add
          </Button>
        </DialogContent>
      </Dialog>
      <Page title="User | Business Poster Admin-UI">
        <Container>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            mb={5}
          >
            <Typography variant="h4" gutterBottom>
              Caegory Layout
            </Typography>
            <Button
              variant="contained"
              startIcon={<Icon icon={plusFill} />}
              title="Add New Category Layout"
              onClick={SubCategoryDialog}
            >
              Add New Sub Category
            </Button>
          </Stack>

          <Card>
            <UserListToolbar
              numSelected={selected.length}
              filterName={filterName}
              onFilterName={handleFilterByName}
            />

            <Scrollbar>
              <TableContainer sx={{ minWidth: 800 }}>
                <Table>
                  <UserListHead
                    order={order}
                    orderBy={orderBy}
                    headLabel={TABLE_HEAD}
                  />

                  <TableBody>
                    {loading ? (
                      filteredImgCategoryLists
                        .slice(
                          page * rowsPerPage,
                          page * rowsPerPage + rowsPerPage
                        )
                        .map((row) => {
                          const isItemSelected =
                            selected.indexOf(row.key) !== -1;
                          const categoryImgCategoryData = {};
                          return (
                            <TableRow
                              hover
                              key={row.key}
                              tabIndex={-1}
                              selected={isItemSelected}
                              aria-checked={isItemSelected}
                            >
                              <TableCell
                                component="th"
                                scope="row"
                                padding="none"
                              >
                                <Stack
                                  direction="row"
                                  alignItems="center"
                                  spacing={2}
                                  marginLeft={2}
                                >
                                  <Typography variant="subtitle2" noWrap>
                                    {row.type || "-"}
                                  </Typography>
                                </Stack>
                              </TableCell>
                              <TableCell align="left">
                                {row.imgCatName || "-"}
                              </TableCell>
                              {/* <TableCell align="left">
                                {row.imgCatId || "-"}
                              </TableCell>
                              <TableCell align="left">
                                {row.imgCatTypeId || "-"}
                              </TableCell> */}
                              {/* <TableCell align="right">
                                <LayoutCategoryMoreMenu
                                  {...categoryImgCategoryData}
                                    setUpdateLoading={imgCategory}
                                />
                              </TableCell> */}
                            </TableRow>
                          );
                        })
                    ) : (
                      <TableBody>
                        <TableRow>
                          <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                            <CircularProgress
                              variant="indeterminate"
                              disableShrink
                              className={classes.top}
                              classes={{
                                circle: classes.circle,
                              }}
                              size={20}
                              thickness={4}
                            />
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    )}
                    {emptyRows > 0 && (
                      <TableRow style={{ height: 53 * emptyRows }}>
                        <TableCell colSpan={6} />
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
            </Scrollbar>

            <TablePagination
              rowsPerPageOptions={[5, 10, 25]}
              component="div"
              count={imgCategory.length}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            />
          </Card>
        </Container>
      </Page>
    </>
  );
}
