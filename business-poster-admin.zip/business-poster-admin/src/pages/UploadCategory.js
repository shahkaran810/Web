import { filter } from "lodash";
import { Icon } from "@iconify/react";
import { useEffect, useState } from "react";
import plusFill from "@iconify/icons-eva/plus-fill";
import { Link as RouterLink } from "react-router-dom";
// material
import {
  Card,
  Table,
  Stack,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
  TablePagination,
  CircularProgress,
  Button,
  Dialog,
  DialogTitle,
  TextField,
  DialogContent,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@material-ui/core";
// components
import Page from "../components/Page";
import Scrollbar from "../components/Scrollbar";
import { UserListHead, UserListToolbar } from "../components/_dashboard/user";
import { LayoutCategoryMoreMenu } from "../components/_dashboard/layoutCategory";
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  doc,
  arrayUnion,
  Timestamp,
} from "firebase/firestore";
import {
  getStorage,
  ref as storageRef,
  getDownloadURL,
  uploadBytesResumable,
} from "firebase/storage";
import { db } from "../index";
import { makeStyles } from "@material-ui/styles";
import { useTheme } from "@emotion/react";
import { useAlert } from "react-alert";

const TABLE_HEAD = [
  { id: "title", label: "Main Category Title", alignRight: false },
  { id: "category", label: "Main Category", alignRight: false },
  { id: "subCategoryName", label: "Sub Category Name", alignRight: false },
  // { id: "imgCatId", label: "Sub Category Id", alignRight: false },
  // { id: "imgCatTypeId", label: "Image Category Type Id", alignRight: false },
  { id: "" },
];

// ----------------------------------------------------------------------

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}
function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return filter(
      array,
      (_user) => _user.name.toLowerCase().indexOf(query.toLowerCase()) !== -1
    );
  }
  return stabilizedThis.map((el) => el[0]);
}

export default function User() {
  const alert = useAlert();
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState("asc");
  const [selected, setSelected] = useState([]);
  const [orderBy, setOrderBy] = useState("name");
  const [filterName, setFilterName] = useState("");
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [categoryLayoutList, setCategoryLayoutList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isSubmitting, setSubmitting] = useState(false);
  const [imageSelected, setImageSelected] = useState("");
  const [title, setTitle] = useState("");
  const [openCategoryLayoutDialog, setOpenCategoryLayoutDialog] =
    useState(false);
  const [categoryType, setCategoryType] = useState("");
  const [categoryTypeName, setCategoryTypeName] = useState([]);
  const [downloadCategory, setDownloadCategory] = useState([]);
  const [imgCategory, setImgCategory] = useState([]);
  const [imgCategoryName, setImgCategoryName] = useState("");

  const useStylesLoading = makeStyles(() => ({
    root: {
      position: "relative",
    },
    top: {
      color: "#007B55",
      animationDuration: "550ms",
      position: "absolute",
      marginLeft: "45%",
    },
    circle: {
      strokeLinecap: "round",
    },
  }));

  const classes = useStylesLoading();

  const useLoading = makeStyles(() => ({
    root: {
      position: "relative",
    },
    top: {
      color: "#007B55",
      animationDuration: "550ms",
      position: "absolute",
      marginLeft: "-10%",
      marginTop: "-4%",
    },
    circle: {
      strokeLinecap: "round",
    },
  }));

  const addLoading = useLoading();

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (event) => {
    setFilterName(event.target.value);
  };

  const Title = (text) => {
    setTitle(text.target.value);
  };

  const handleChange = (e) => {
    const image = e.target.files[0];
    setImageSelected(image);
  };

  const handleChangeCategoryType = (event) => {
    setCategoryType(event.target.value);
  };
  const handleImageCategory = (event) => {
    setImgCategoryName(event.target.value);
  };
  const storage = getStorage();

  const CategoryLayoutDialog = () => {
    setOpenCategoryLayoutDialog(true);
  };
  const CategoryLayoutDialogClose = () => {
    setOpenCategoryLayoutDialog(false);
  };

  const emptyRows =
    page > 0
      ? Math.max(0, (1 + page) * rowsPerPage - categoryLayoutList.length)
      : 0;

  const filteredCategoryLayoutLists = applySortFilter(
    categoryLayoutList,
    getComparator(order, orderBy),
    filterName
  );

  const isUserNotFound = filteredCategoryLayoutLists.length === 0;

  const getLayoutCategoryList = () => {
    const categoryLayoutCol = collection(db, "layout_category");
    const snapshot = getDocs(categoryLayoutCol)
      .then((snapshot) => {
        const categoryLayoutList = [];
        snapshot.forEach((doc) => {
          const {
            title,
            category,
            categoryId,
            imgCatTypeId,
            imgCatId,
            imageCategoryName,
            layoutImages,
          } = doc.data();

          categoryLayoutList.push({
            key: doc.id,
            doc,
            title,
            category,
            categoryId,
            imgCatTypeId,
            imgCatId,
            imageCategoryName,
            layoutImages: layoutImages,
          });
        });
        setCategoryLayoutList(categoryLayoutList);
        setLoading(true);
        // console.log("Category Layout List: ", categoryLayoutList);
      })
      .catch((error) => console.log(error));
  };

  const handleUpload = () => {
    setSubmitting(true);
    // const promises = [];
    if (imageSelected === "") {
      console.log("Please Select Image");
    } else if (title === "") {
      console.log("Enter Title");
    } else {
      const storeImagesRef = storageRef(storage, `photo/${imageSelected.name}`);

      const metadata = {
        contentType: imageSelected.type,
      };

      const uploadTask = uploadBytesResumable(
        storeImagesRef,
        imageSelected,
        metadata
      );
      // promises.push(uploadTask);
      uploadTask.on(
        "state_changed",
        (snapshot) => {
          const progress =
            (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log("Upload is " + progress + "% done");
          switch (snapshot.state) {
            case "paused":
              console.log("Upload is paused");
              break;
            case "running":
              console.log("Upload is running");
              break;
          }
        },
        (error) => {
          console.log(`Error: ${error}`);
        },
        () => {
          getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
            // setImageUrl(downloadURL);
            CreatelayoutImages(downloadURL);
            // console.log("DownloadUrl:", downloadURL);
            setImageSelected("");
          });
          CategoryLayoutDialogClose();
          setSubmitting(false);
          alert.success("Image Uploaded!");
        }
      );
    }
    // Promise.all(promises)
    //   .then(() => alert("Image Uploaded"))
    //   .catch((error) => alert(error));
  };

  const CreatelayoutImages = async (url) => {
    const currentDateTime = Timestamp.now().toDate().toString();
    const docRef = await addDoc(collection(db, "layout_category"), {
      category: categoryType.imgCatTypeName,
      createdAt: currentDateTime,
      title: title,
      // imgCatId: arrayUnion(...[imgCategoryName.key]),
      // imgCatTypeId: arrayUnion(...[categoryType.key]),
      // imageCategoryName: arrayUnion(...[imgCategoryName.imgCatName]),
      layoutImages: arrayUnion(...[{ image: { uri: url } }]),
      imgCatId: imgCategoryName.key,
      imgCatTypeId: categoryType.key,
      imageCategoryName: imgCategoryName.imgCatName,
    });

    const UpdateRef = doc(db, "layout_category", docRef.id);

    await updateDoc(UpdateRef, {
      id: docRef.id,
    });

    // console.log(`Image Uploaded`);
    // setSubmitting(false);
    setLoading(true);
    getLayoutCategoryList();
    setLoading(false);
  };

  const getCategoryType = () => {
    const userCol = collection(db, "imageCategoryType");
    const snapshot = getDocs(userCol)
      .then((snapshot) => {
        const categoryTypeName = [];
        snapshot.forEach((doc) => {
          categoryTypeName.push({
            key: doc.id,
            ...doc.data(),
          });
        });
        setCategoryTypeName(categoryTypeName);
      })
      .catch((error) => console.log(error));
  };

  const getImageCategory = () => {
    const userCol = collection(db, "imageCategory");
    const snapshot = getDocs(userCol)
      .then((snapshot) => {
        const imageCategory = [];
        snapshot.forEach((doc) => {
          imageCategory.push({
            key: doc.id,
            ...doc.data(),
          });
        });
        setImgCategory(imageCategory);
        console.log("Image Category Type : ", imageCategory);
      })
      .catch((error) => console.log(error));
  };

  const getDownloadCategory = () => {
    const userCol = collection(db, "downloadCategory");
    const snapshot = getDocs(userCol)
      .then((snapshot) => {
        const downloadCategory = [];
        snapshot.forEach((doc) => {
          const { categoryTitle } = doc.data();
          downloadCategory.push({
            key: doc.id,
            doc,
            categoryTitle,
          });
        });
        setDownloadCategory(downloadCategory);
      })
      .catch((error) => console.log(error));
  };

  useEffect(() => {
    getLayoutCategoryList();
    getCategoryType();
    getDownloadCategory();
    getImageCategory();
  }, []);

  return (
    <>
      <Dialog
        open={openCategoryLayoutDialog}
        onClose={CategoryLayoutDialogClose}
        aria-labelledby="form-dialog-title"
      >
        <DialogTitle id="form-dialog-title">Add Category Layout</DialogTitle>
        <DialogContent>
          <Stack spacing={3}>
            <TextField
              fullWidth
              margin="dense"
              label="Title"
              value={title}
              onChange={Title}
            />
            <FormControl sx={{ minWidth: 200 }}>
              <InputLabel id="demo-simple-select-autowidth-label">
                Select Sub Category Type
              </InputLabel>
              <Select
                labelId="demo-simple-select-autowidth-label"
                id="demo-simple-select-autowidth"
                value={categoryType}
                onChange={handleChangeCategoryType}
                autoWidth
                label="Select sub Category Type"
              >
                {categoryTypeName.map((name) => (
                  <MenuItem key={name.key} value={name}>
                    {name.imgCatTypeName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl sx={{ minWidth: 200 }}>
              <InputLabel id="demo-simple-select-autowidth-label">
                Select Sub Category Name
              </InputLabel>
              <Select
                labelId="demo-simple-select-autowidth-label"
                id="demo-simple-select-autowidth"
                value={imgCategoryName}
                onChange={handleImageCategory}
                autoWidth
                label="Select Sub Category Name"
              >
                {imgCategory.map((name) => (
                  <MenuItem key={name.key} value={name}>
                    {name.imgCatName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <input type="file" onChange={handleChange} />
          </Stack>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            sx={{ my: 2 }}
          ></Stack>

          <Button
            fullWidth
            size="large"
            type="submit"
            variant="contained"
            disabled={isSubmitting}
            onClick={handleUpload}
          >
            {isSubmitting && (
              <i>
                <CircularProgress
                  variant="indeterminate"
                  disableShrink
                  className={addLoading.top}
                  classes={{
                    circle: addLoading.circle,
                  }}
                  size={20}
                  thickness={4}
                />
              </i>
            )}
            Add
          </Button>
        </DialogContent>
      </Dialog>
      <Page title="User | Business Poster Admin-UI">
        <Container>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            mb={5}
          >
            <Typography variant="h4" gutterBottom>
              Caegory Layout
            </Typography>
            <Button
              variant="contained"
              startIcon={<Icon icon={plusFill} />}
              title="Add New Category Layout"
              onClick={CategoryLayoutDialog}
            >
              Add New Category Layout
            </Button>
          </Stack>

          <Card>
            <UserListToolbar
              numSelected={selected.length}
              filterName={filterName}
              onFilterName={handleFilterByName}
            />

            <Scrollbar>
              <TableContainer sx={{ minWidth: 800 }}>
                <Table>
                  <UserListHead
                    order={order}
                    orderBy={orderBy}
                    headLabel={TABLE_HEAD}
                  />

                  <TableBody>
                    {loading ? (
                      filteredCategoryLayoutLists
                        .slice(
                          page * rowsPerPage,
                          page * rowsPerPage + rowsPerPage
                        )
                        .map((row) => {
                          const isItemSelected =
                            selected.indexOf(row.key) !== -1;
                          const categoryImgListData = {
                            categoryImgKey: row.key,
                            layoutImages: row.layoutImages,
                            title: row.title,
                          };
                          return (
                            <TableRow
                              hover
                              key={row.key}
                              tabIndex={-1}
                              selected={isItemSelected}
                              aria-checked={isItemSelected}
                            >
                              <TableCell
                                component="th"
                                scope="row"
                                padding="none"
                              >
                                <Stack
                                  direction="row"
                                  alignItems="center"
                                  spacing={2}
                                  marginLeft={2}
                                >
                                  <Typography variant="subtitle2" noWrap>
                                    {row.title || "-"}
                                  </Typography>
                                </Stack>
                              </TableCell>
                              <TableCell align="left">
                                {row.category || "-"}
                              </TableCell>
                              <TableCell align="left">
                                {row.imageCategoryName || "-"}
                              </TableCell>
                              {/* <TableCell align="left">
                                {row.imgCatId || "-"}
                              </TableCell>
                              <TableCell align="left">
                                {row.imgCatTypeId || "-"}
                              </TableCell> */}
                              <TableCell align="right">
                                <LayoutCategoryMoreMenu
                                  {...categoryImgListData}
                                  setUpdateLoading={getLayoutCategoryList}
                                  getCategoryType={categoryTypeName}
                                  getImageCategory={imgCategory}
                                />
                              </TableCell>
                            </TableRow>
                          );
                        })
                    ) : (
                      <TableBody>
                        <TableRow>
                          <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                            <CircularProgress
                              variant="indeterminate"
                              disableShrink
                              className={classes.top}
                              classes={{
                                circle: classes.circle,
                              }}
                              size={20}
                              thickness={4}
                            />
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    )}
                    {emptyRows > 0 && (
                      <TableRow style={{ height: 53 * emptyRows }}>
                        <TableCell colSpan={6} />
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
            </Scrollbar>

            <TablePagination
              rowsPerPageOptions={[5, 10, 25]}
              component="div"
              count={categoryLayoutList.length}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            />
          </Card>
        </Container>
      </Page>
    </>
  );
}
