import { useEffect } from "react";
import { useLocation } from "react-router-dom";
// material
import { Stack, Container, Typography, Grid } from "@material-ui/core";

// components
import Page from "../components/Page";
import Scrollbar from "../components/Scrollbar";
import { UserListHead } from "../components/_dashboard/user";
// ----------------------------------------------------------------------

const TABLE_HEAD = [
  { id: "mobile number", label: "Mobile Number", alignRight: false },
  { id: "address", label: "Address", alignRight: false },
  { id: "business", label: "Business", alignRight: false },
  { id: "" },
];

export default function UserInfo() {
  const state = useLocation();

  return (
    <Page title="User | Business Poster Admin-UI">
      <Container>
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          mb={5}
        >
          <Typography variant="h4" gutterBottom>
            /User's Basic Information
          </Typography>
        </Stack>

        <Grid container spacing={2}>
          <Grid item lg={2} xs={12}>
            <Typography variant="h6">Name</Typography>
            <Typography variant="body2" sx={{ color: "text.primary" }}>
              {state.state.user_Name || state.state.user_FullName || "-"}
            </Typography>
          </Grid>
          <Grid item lg={2} xs={12}>
            <Typography variant="h6">Email</Typography>
            <Typography variant="body2" sx={{ color: "text.primary" }}>
              {state.state.user_Email || "-"}
            </Typography>
          </Grid>
          <Grid item lg={2} xs={12}>
            <Typography variant="h6">Gender</Typography>
            <Typography variant="body2" sx={{ color: "text.primary" }}>
              {state.state.user_Gender || "-"}
            </Typography>
          </Grid>
          <Grid item lg={2} xs={12}>
            <Typography variant="h6">Mobile Number</Typography>
            <Typography variant="body2" sx={{ color: "text.primary" }}>
              {state.state.user_Mobile || "-"}
            </Typography>
          </Grid>
          <Grid item lg={2} xs={12}>
            <Typography variant="h6">Address</Typography>
            <Typography variant="body2" sx={{ color: "text.primary" }}>
              {state.state.user_Address || "-"}
            </Typography>
          </Grid>
          <Grid item lg={2} xs={12}>
            <Typography variant="h6">Business Name</Typography>
            <Typography variant="body2" sx={{ color: "text.primary" }}>
              {state.state.user_Business_Name || "-"}
            </Typography>
          </Grid>
        </Grid>
      </Container>
    </Page>
  );
}
