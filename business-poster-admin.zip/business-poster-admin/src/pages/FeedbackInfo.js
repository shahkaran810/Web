import { useEffect } from "react";
import { useLocation } from "react-router-dom";
// material
import { Stack, Container, Typography, Grid } from "@material-ui/core";
// components
import Page from "../components/Page";

// ----------------------------------------------------------------------
export default function UserInfo() {
  const state = useLocation();
  return (
    <Page title="User | Business Poster Admin-UI">
      <Container>
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          mb={5}
        >
          <Typography variant="h4" gutterBottom>
            /feedback Information
          </Typography>
        </Stack>

        <Grid container spacing={2}>
          <Grid item lg={2} xs={12}>
            <Typography variant="h6">Title</Typography>
            <Typography variant="body2" sx={{ color: "text.primary" }}>
              {state.state.feedback_Title || "-"}
            </Typography>
          </Grid>
          <Grid item lg={2} xs={12}>
            <Typography variant="h6">Message</Typography>
            <Typography variant="body2" sx={{ color: "text.primary" }}>
              {state.state.feedback_Message || "-"}
            </Typography>
          </Grid>
        </Grid>
      </Container>
    </Page>
  );
}
