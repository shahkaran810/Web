import { useState, useEffect, useRef, useCallback } from "react";
import { Icon } from "@iconify/react";
import plusFill from "@iconify/icons-eva/plus-fill";
// material
import {
  Container,
  Grid,
  Stack,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  DialogContentText,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  Box,
  Card,
} from "@material-ui/core";
// components
import Page from "../components/Page";
import { LayoutCategoryImageList } from "../components/_dashboard/layoutCategory";
import { useLocation } from "react-router-dom";
import {
  getStorage,
  ref as storageRef,
  getDownloadURL,
  uploadBytesResumable,
} from "firebase/storage";
import {
  updateDoc,
  doc,
  arrayUnion,
  collection,
  getDocs,
  addDoc,
} from "firebase/firestore";
import { db } from "src";
import { makeStyles } from "@material-ui/styles";
import { useAlert } from "react-alert";
import { styled } from "@material-ui/core/styles";

export default function LayoutCategoryUploadImg() {
  const alert = useAlert();
  const [layoutImg, setLayoutImg] = useState([]);
  const [open, setOpen] = useState(false);
  const [imageSelected, setImageSelected] = useState("");
  const [imageUrl, setImageUrl] = useState([]);
  const [loading, setLoading] = useState(true);
  const [imgCategory, setImgCategory] = useState([]);
  const [imgCategoryName, setImgCategoryName] = useState("");
  const [categoryTypeName, setCategoryTypeName] = useState([]);
  const [categoryType, setCategoryType] = useState("");
  const [categoryLayoutList, setCategoryLayoutList] = useState([]);
  const [isSubmitting, setSubmitting] = useState(false);

  const useStylesLoading = makeStyles(() => ({
    root: {
      position: "relative",
    },
    top: {
      color: "#007B55",
      animationDuration: "550ms",
      position: "absolute",
      marginLeft: "30%",
    },
    circle: {
      strokeLinecap: "round",
    },
  }));

  const useLoading = makeStyles(() => ({
    root: {
      position: "relative",
    },
    top: {
      color: "#007B55",
      animationDuration: "550ms",
      position: "absolute",
      marginLeft: "-10%",
      marginTop: "-4%",
    },
    circle: {
      strokeLinecap: "round",
    },
  }));

  const addLoading = useLoading();

  const classes = useStylesLoading();

  const state = useLocation();
  const storage = getStorage();

  const handleClose = () => {
    setOpen(false);
  };

  const handleOpen = () => {
    setOpen(true);
  };

  const handleImageChange = (e) => {
    // console.log(e.target.files[])
    if (e.target.files) {
      const filesArray = Array.from(e.target.files).map((file) =>
        URL.createObjectURL(file)
      );

      // console.log("filesArray: ", filesArray);

      setImageSelected((prevImages) => prevImages.concat(filesArray));
      Array.from(e.target.files).map(
        (file) => URL.revokeObjectURL(file) // avoid memory leak
      );
    }
  };

  // const renderPhotos = (source) => {
  //   console.log("source: ", source);
  //   return source.map((photo, i) => {
  //     return (
  //       <Grid
  //         key={i}
  //         item
  //         xs={12}
  //         sm={6}
  //         md={3}
  //         style={{ marginLeft: 25, marginTop: 15 }}
  //       >
  //         <Card>
  //           <Box
  //             sx={{
  //               position: "relative",
  //               top: 0,
  //               width: "100%",
  //               height: "100%",
  //               objectFit: "cover",
  //             }}
  //           >
  //             <img src={photo} alt="" key={photo} />
  //           </Box>
  //         </Card>
  //       </Grid>
  //     );
  //   });
  //   // return source.map((photo) => {
  //   //   <Grid item xs={12} sm={6} md={3}>
  //   //     <Box sx={{ pt: "100%", position: "relative" }}>
  //   //       <img src={photo} alt="" key={photo} />
  //   //     </Box>
  //   //   </Grid>;
  //   //   // return <img src={photo} alt="" key={photo} />
  //   // });
  // };

  const handleChange = (e) => {
    // for (let i = 0; i < e.target.files.length; i++) {
    //   const image = e.target.files[i];
    //   image["id"] = Math.random();
    //   setImageSelected((prevState) => [...prevState, image]);
    // }
    const image = e.target.files[0];
    setImageSelected(image);
  };
  const handleImageCategory = (event) => {
    setImgCategoryName(event.target.value);
  };
  const handleChangeCategoryType = (event) => {
    setCategoryType(event.target.value);
  };
  // const CreatelayoutImages = async ([url]) => {
  const CreatelayoutImages = async (url) => {
    console.log("Url000: ", url);
    const layoutImageRef = doc(db, "layout_category", state.state.id);

    await updateDoc(layoutImageRef, {
      layoutImages: arrayUnion(...[{ image: { uri: url } }]),
      // imageCategoryName: arrayUnion(...[imgCategoryName.imgCatName]),
      // imgCatId: arrayUnion(...[imgCategoryName.key]),
      // imgCatTypeId: arrayUnion(...[categoryType.key]),
    });
    // setLayoutImg(url);
    if ("caches" in window) {
      caches.keys().then((names) => {
        names.forEach((name) => {
          caches.delete(name);
        });
      });
      // window.location.reload(true);
      // setLayoutImg(url);
    }
  };

  const getNewURL = useCallback(
    function getNewURL(Url) {
      setLayoutImg(Url);
    },
    [layoutImg]
  );

  const handleUpload = () => {
    setSubmitting(true);
    // imageSelected.map((image) => {
    if (imageSelected === "") {
      alert.error("Select Image!");
    } else {
      // console.log("Selected Image :", imageSelected);
      const storeImagesRef = storageRef(storage, `photo/${imageSelected.name}`);

      const metadata = {
        contentType: imageSelected.type,
      };

      const uploadTask = uploadBytesResumable(
        storeImagesRef,
        imageSelected,
        metadata
      );
      uploadTask.on(
        "state_changed",
        (snapshot) => {
          const progress =
            (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log("Upload is " + progress + "% done");
          switch (snapshot.state) {
            case "paused":
              console.log("Upload is paused");
              break;
            case "running":
              console.log("Upload is running");
              break;
          }
        },
        (error) => {
          console.log(`Error: ${error}`);
        },
        () => {
          getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
            setImageUrl((prevState) => [...prevState, downloadURL]);
            CreatelayoutImages(downloadURL);
            setImageSelected("");
            alert.success("Image Uploaded!");
          });
          handleClose();
          // getLayoutCategoryList();
          setSubmitting(false);
        }
      );
    }
    // });
  };

  const getLayoutCategoryList = () => {
    const categoryLayoutCol = collection(db, "layout_category");
    const snapshot = getDocs(categoryLayoutCol)
      .then((snapshot) => {
        const categoryLayoutList = [];
        snapshot.forEach((doc) => {
          categoryLayoutList.push({
            key: doc.id,
            ...doc.data().layoutImages,
          });
        });
        setCategoryLayoutList(categoryLayoutList);
        console.log("Category Layout List: ", categoryLayoutList);
      })
      .catch((error) => console.log(error));
  };

  const getImageCategory = () => {
    const userCol = collection(db, "imageCategory");
    const snapshot = getDocs(userCol)
      .then((snapshot) => {
        const imageCategory = [];
        snapshot.forEach((doc) => {
          imageCategory.push({
            key: doc.id,
            ...doc.data(),
          });
        });
        setImgCategory(imageCategory);
        console.log("Image Category Type : ", imageCategory);
      })
      .catch((error) => console.log(error));
  };

  const getCategoryType = () => {
    const userCol = collection(db, "imageCategoryType");
    const snapshot = getDocs(userCol)
      .then((snapshot) => {
        const categoryTypeName = [];
        snapshot.forEach((doc) => {
          categoryTypeName.push({
            key: doc.id,
            ...doc.data(),
          });
        });
        setCategoryTypeName(categoryTypeName);
      })
      .catch((error) => console.log(error));
  };

  useEffect(() => {
    setLayoutImg(state.state.img);
    setLoading(false);
    setTimeout(() => {
      setLoading(true);
    }, 4000);
    getImageCategory();
    getCategoryType();
  }, []);
  return (
    <>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="form-dialog-title"
      >
        <DialogTitle id="form-dialog-title">Upload Category Image</DialogTitle>
        <DialogContent>
          <Stack spacing={3}>
            <input type="file" onChange={handleChange} multiple />
            {/* <FormControl sx={{ minWidth: 200 }}>
              <InputLabel id="demo-simple-select-autowidth-label">
                Sub Image Category
              </InputLabel>
              <Select
                labelId="demo-simple-select-autowidth-label"
                id="demo-simple-select-autowidth"
                value={imgCategoryName}
                onChange={handleImageCategory}
                autoWidth
                label="Sub Imahe Category"
              >
                {imgCategory.map((name) => (
                  <MenuItem key={name.key} value={name}>
                    {name.imgCatName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl sx={{ minWidth: 200 }}>
              <InputLabel id="demo-simple-select-autowidth-label">
                Select Sub Category Type
              </InputLabel>
              <Select
                labelId="demo-simple-select-autowidth-label"
                id="demo-simple-select-autowidth"
                value={categoryType}
                onChange={handleChangeCategoryType}
                autoWidth
                label="Select sub Category Type"
              >
                {categoryTypeName.map((name) => (
                  <MenuItem key={name.key} value={name}>
                    {name.imgCatTypeName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl> */}
          </Stack>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            sx={{ my: 2 }}
          ></Stack>

          <Button
            fullWidth
            size="large"
            type="submit"
            variant="contained"
            disabled={isSubmitting}
            onClick={handleUpload}
          >
            {isSubmitting && (
              <i>
                <CircularProgress
                  variant="indeterminate"
                  disableShrink
                  className={addLoading.top}
                  classes={{
                    circle: addLoading.circle,
                  }}
                  size={20}
                  thickness={4}
                />
              </i>
            )}
            Update
          </Button>
        </DialogContent>
      </Dialog>
      <Page title="Dashboard: LayoutCategory | Business Poster Admin-UI">
        <Container>
          <Typography variant="h4" sx={{ mb: 5 }}>
            Layout Category
          </Typography>

          <Stack
            direction="row"
            flexWrap="wrap-reverse"
            alignItems="center"
            justifyContent="flex-end"
            sx={{ mb: 5 }}
          >
            <Button
              variant="contained"
              startIcon={<Icon icon={plusFill} />}
              title="Upload Image"
              onClick={handleOpen}
            >
              Upload Image
            </Button>
          </Stack>
          {loading ? (
            <Grid container spacing={3}>
              {layoutImg.map((image, i) => {
                return (
                  <Grid key={i} item xs={12} sm={6} md={3}>
                    <LayoutCategoryImageList
                      ImageUri={image.image.uri}
                      docID={state.state.id}
                      getNewURL={getNewURL}
                    />
                  </Grid>
                );
              })}
              {/* <div className="result">{renderPhotos(imageSelected)}</div> */}
              {imageUrl.map((url, i) => {
                return (
                  <Grid key={i} item xs={12} sm={6} md={3}>
                    <LayoutCategoryImageList
                      ImageUri={url}
                      docID={state.state.id}
                      // docID={id}
                      getNewURL={getNewURL}
                    />
                  </Grid>
                );
              })}
            </Grid>
          ) : (
            <Grid>
              <CircularProgress
                variant="indeterminate"
                disableShrink
                className={classes.top}
                classes={{
                  circle: classes.circle,
                }}
                size={20}
                thickness={4}
              />
            </Grid>
          )}
        </Container>
      </Page>
    </>
  );
}
