import { filter } from "lodash";
import { Icon } from "@iconify/react";
import { sentenceCase } from "change-case";
import { useEffect, useState } from "react";
import plusFill from "@iconify/icons-eva/plus-fill";
import { Link as RouterLink } from "react-router-dom";
import * as Yup from "yup";
import { useFormik, Form, FormikProvider } from "formik";

// material
import {
  Card,
  Table,
  Stack,
  Avatar,
  Button,
  Checkbox,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
  TablePagination,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
} from "@material-ui/core";
// components
import Page from "../components/Page";
import Scrollbar from "../components/Scrollbar";
import SearchNotFound from "../components/SearchNotFound";
import { UserListHead, UserListToolbar } from "../components/_dashboard/user";

import { CategoryMoreMenu } from "../components/_dashboard/category";

import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  doc,
} from "firebase/firestore";
import { db } from "../../src/index";

import { makeStyles } from "@material-ui/styles";
import { LoadingButton } from "@material-ui/lab";

// ----------------------------------------------------------------------
const TABLE_HEAD = [
  {
    id: "imgCatTypeName",
    label: "Image Category Type Name",
    alignRight: false,
  },
  {
    id: "imgCatTypeId",
    label: "Image Category ID",
    alignRight: false,
  },
  { id: "" },
];

// ----------------------------------------------------------------------

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return filter(
      array,
      (_user) => _user.name.toLowerCase().indexOf(query.toLowerCase()) !== -1
    );
  }
  return stabilizedThis.map((el) => el[0]);
}

export default function Category() {
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState("asc");
  const [selected, setSelected] = useState([]);
  const [orderBy, setOrderBy] = useState("name");
  const [filterName, setFilterName] = useState("");
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [categoryList, setCategoryList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isSubmitting, setSubmitting] = useState(false);
  const [openAddCategoryDialog, setOpenAddCategoryDialog] = useState(false);

  const handleOpenAddCategoryDialog = () => {
    setOpenAddCategoryDialog(true);
  };

  const handleAddCategoryDialogClose = () => {
    setOpenAddCategoryDialog(false);
  };

  const useStylesLoading = makeStyles((theme) => ({
    root: {
      position: "relative",
    },
    top: {
      color: "#007B55",
      animationDuration: "550ms",
      position: "absolute",
      marginLeft: "45%",
    },
    circle: {
      strokeLinecap: "round",
    },
  }));

  const classes = useStylesLoading();

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelecteds = categoryList.map((n) => n.name);
      setSelected(newSelecteds);
      return;
    }
    setSelected([]);
  };

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1)
      );
    }
    setSelected(newSelected);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (event) => {
    setFilterName(event.target.value);
  };

  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - categoryList.length) : 0;

  const filteredCategoryLists = applySortFilter(
    categoryList,
    getComparator(order, orderBy),
    filterName
  );

  const isUserNotFound = filteredCategoryLists.length === 0;

  const getUserList = () => {
    const userCol = collection(db, "imageCategoryType");
    const snapshot = getDocs(userCol)
      .then((snapshot) => {
        const categoryList = [];
        snapshot.forEach((doc) => {
          const { imgCatTypeName } = doc.data();
          categoryList.push({
            key: doc.id,
            doc,
            imgCatTypeName,
          });
        });
        setCategoryList(categoryList);
        setLoading(true);
        // console.log("Category List: ", categoryList);
      })
      .catch((error) => console.log(error));
  };

  const handleAddCategory = () => {};

  useEffect(() => {
    getUserList();
  }, []);

  const AddCategorySchema = Yup.object().shape({
    categoryName: Yup.string()
      .min(2, "Too Short!")
      .max(50, "Too Long!")
      .required("Category Name required"),
  });

  const formik = useFormik({
    initialValues: {
      categoryName: "",
    },
    validationSchema: AddCategorySchema,
    onSubmit: async (values) => {
      setSubmitting(true);
      let { categoryName } = values;
      const docRef = await addDoc(collection(db, "imageCategoryType"), {
        imgCatTypeName: categoryName,
      });
      // console.log("Document ID: ", docRef.id);
      const UpdateRef = doc(db, "imageCategoryType", docRef.id);

      await updateDoc(UpdateRef, {
        imgCatTypeId: docRef.id,
        imgCatTypeName: categoryName,
      });
      setSubmitting(false);
      handleAddCategoryDialogClose();
      getUserList();
    },
  });

  const { errors, touched, handleSubmit, getFieldProps } = formik;

  return (
    <Page title="User | Business Poster Admin-UI">
      <Container>
        <Dialog
          open={openAddCategoryDialog}
          onClose={handleAddCategoryDialogClose}
          aria-labelledby="form-dialog-title"
        >
          <DialogTitle id="form-dialog-title">Add Category</DialogTitle>
          <DialogContent>
            <FormikProvider value={formik}>
              <Form autoComplete="off" noValidate onSubmit={handleSubmit}>
                <Stack spacing={3}>
                  <TextField
                    fullWidth
                    margin="dense"
                    label="Category Name"
                    {...getFieldProps("categoryName")}
                    error={Boolean(touched.categoryName && errors.categoryName)}
                    helperText={touched.categoryName && errors.categoryName}
                  />
                </Stack>
                <Stack
                  direction="row"
                  alignItems="center"
                  justifyContent="space-between"
                  sx={{ my: 2 }}
                ></Stack>

                <LoadingButton
                  fullWidth
                  size="large"
                  type="submit"
                  variant="contained"
                  loading={isSubmitting}
                >
                  Add
                </LoadingButton>
              </Form>
            </FormikProvider>
          </DialogContent>
        </Dialog>

        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          mb={5}
        >
          <Typography variant="h4" gutterBottom>
            Category
          </Typography>
          <Button
            variant="contained"
            startIcon={<Icon icon={plusFill} />}
            title="New Category"
            onClick={handleOpenAddCategoryDialog}
          >
            New Category
          </Button>
        </Stack>
        <Card>
          <UserListToolbar
            numSelected={selected.length}
            filterName={filterName}
            onFilterName={handleFilterByName}
          />

          <Scrollbar>
            <TableContainer sx={{ minWidth: 800 }}>
              <Table>
                <UserListHead
                  order={order}
                  orderBy={orderBy}
                  headLabel={TABLE_HEAD}
                />

                <TableBody>
                  {loading ? (
                    filteredCategoryLists
                      .slice(
                        page * rowsPerPage,
                        page * rowsPerPage + rowsPerPage
                      )
                      .map((row) => {
                        const isItemSelected = selected.indexOf(row.key) !== -1;
                        const categoryListData = {
                          categoryID: row.key,
                          categoryTypeName: row.imgCatTypeName,
                        };
                        return (
                          <TableRow
                            hover
                            key={row.key}
                            tabIndex={-1}
                            selected={isItemSelected}
                            aria-checked={isItemSelected}
                          >
                            <TableCell
                              component="th"
                              scope="row"
                              padding="none"
                            >
                              <Stack
                                direction="row"
                                alignItems="center"
                                spacing={2}
                                marginLeft={2}
                              >
                                <Typography variant="subtitle2" noWrap>
                                  {row.imgCatTypeName || "-"}
                                </Typography>
                              </Stack>
                            </TableCell>

                            <TableCell align="left">{row.key || "-"}</TableCell>

                            <TableCell align="right">
                              <CategoryMoreMenu
                                {...categoryListData}
                                setUpdateCategoryLoading={getUserList}
                              />
                            </TableCell>
                          </TableRow>
                        );
                      })
                  ) : (
                    <TableBody>
                      <TableRow>
                        <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                          <CircularProgress
                            variant="indeterminate"
                            disableShrink
                            className={classes.top}
                            classes={{
                              circle: classes.circle,
                            }}
                            size={20}
                            thickness={4}
                          />
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  )}
                  {emptyRows > 0 && (
                    <TableRow style={{ height: 53 * emptyRows }}>
                      <TableCell colSpan={6} />
                    </TableRow>
                  )}
                </TableBody>
                {/* {isUserNotFound && (
                  <TableBody>
                    <TableRow>
                      <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                        <SearchNotFound searchQuery={filterName} />
                      </TableCell>
                    </TableRow>
                  </TableBody>
                )} */}
              </Table>
            </TableContainer>
          </Scrollbar>

          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={categoryList.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Card>
      </Container>
    </Page>
  );
}
