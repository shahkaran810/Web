import { Navigate, useRoutes, Routes, Route } from "react-router-dom";
// layouts
import DashboardLayout from "./layouts/dashboard";
import LogoOnlyLayout from "./layouts/LogoOnlyLayout";
import Login from "./pages/Login";
import Register from "./pages/Register";
import DashboardApp from "./pages/DashboardApp";
import Products from "./pages/Products";
import Blog from "./pages/Blog";
import User from "./pages/User";
import NotFound from "./pages/Page404";
import Feedback from "./pages/FeedBack";
import UserInfo from "./pages/UserInfo";
import FeedbackInfo from "./pages/FeedbackInfo";
import Category from "./pages/Category";
import UploadCategory from "./pages/UploadCategory";
import LayoutCategoryUploadImg from "./pages/LayoutCategoryUploadImg";
import SubCategory from "./pages/SubCategory";
import { useState } from "react";

export default function AppRoutes() {
  function PrivateRoute({ children }) {
    return localStorage.getItem("isLoggedIn", true) ? (
      children
    ) : (
      <Navigate to="/login" />
    );
  }

  return (
    <Routes>
      <Route element={<LogoOnlyLayout />}>
        <Route path="/" element={<Navigate to="/dashboard/app" replace />} />
      </Route>

      <Route element={<LogoOnlyLayout />}>
        <Route path="/login" element={<Login />} />
      </Route>

      <Route element={<LogoOnlyLayout />}>
        <Route path="/register" element={<Register />} />
      </Route>

      <Route element={<LogoOnlyLayout />}>
        <Route path="/404" element={<NotFound />} />
      </Route>

      <Route element={<LogoOnlyLayout />}>
        <Route path="/*" element={<Navigate to="/404" />} />
      </Route>

      <Route element={<DashboardLayout />}>
        <Route path="/dashboard" element={<Navigate to="/dashboard/app" />} />
        <Route
          path="/dashboard/app"
          element={
            <PrivateRoute>
              <DashboardApp />
            </PrivateRoute>
          }
        />
      </Route>

      <Route element={<DashboardLayout />}>
        <Route
          path="/dashboard/user"
          element={
            <PrivateRoute>
              <User />
            </PrivateRoute>
          }
        />
      </Route>

      <Route element={<DashboardLayout />}>
        <Route
          path="/dashboard/products"
          element={
            <PrivateRoute>
              <Products />
            </PrivateRoute>
          }
        />
      </Route>

      <Route element={<DashboardLayout />}>
        <Route
          path="/dashboard/blog"
          element={
            <PrivateRoute>
              <Blog />
            </PrivateRoute>
          }
        />
      </Route>

      <Route element={<DashboardLayout />}>
        <Route
          path="/dashboard/info"
          element={
            <PrivateRoute>
              <UserInfo />
            </PrivateRoute>
          }
        />
      </Route>

      <Route element={<DashboardLayout />}>
        <Route
          path="/dashboard/feedback"
          element={
            <PrivateRoute>
              <Feedback />
            </PrivateRoute>
          }
        />
      </Route>

      <Route element={<DashboardLayout />}>
        <Route
          path="/dashboard/feedbackinfo"
          element={
            <PrivateRoute>
              <FeedbackInfo />
            </PrivateRoute>
          }
        />
      </Route>

      <Route element={<DashboardLayout />}>
        <Route
          path="/dashboard/category"
          element={
            <PrivateRoute>
              <Category />
            </PrivateRoute>
          }
        />
      </Route>

      <Route element={<DashboardLayout />}>
        <Route
          path="/dashboard/uploadCategory"
          element={
            <PrivateRoute>
              <UploadCategory />
            </PrivateRoute>
          }
        />
      </Route>
      <Route element={<DashboardLayout />}>
        <Route
          path="/dashboard/layoutCategory"
          element={
            <PrivateRoute>
              <LayoutCategoryUploadImg />
            </PrivateRoute>
          }
        />
      </Route>
      <Route element={<DashboardLayout />}>
        <Route
          path="/dashboard/subCategory"
          element={
            <PrivateRoute>
              <SubCategory />
            </PrivateRoute>
          }
        />
      </Route>
    </Routes>
  );
}
