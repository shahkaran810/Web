// scroll bar
import "simplebar/src/simplebar.css";

import ReactDOM from "react-dom";
import { BrowserRouter } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";

//
import App from "./App";
import * as serviceWorker from "./serviceWorker";
import reportWebVitals from "./reportWebVitals";

// ----------------------------------------------------------------------

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

import { positions, Provider } from "react-alert";
import AlertTemplate from "react-alert-template-basic";

const options = {
  timeout: 5000,
  position: positions.BOTTOM_CENTER,
};

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseApp = initializeApp({
  apiKey: "AIzaSyDyQxjuzWvb4UubCIZErMGY-_O46QJMPFc",
  authDomain: "md-poc-e83db.firebaseapp.com",
  databaseURL:
    "https://md-poc-e83db-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "md-poc-e83db",
  storageBucket: "md-poc-e83db.appspot.com",
  messagingSenderId: "1037132175770",
  appId: "1:1037132175770:web:d6054bf455a77b45588223",
  measurementId: "G-91HX18NZWX",
});

// Initialize Firebase
const db = getFirestore(firebaseApp);
export { db };

ReactDOM.render(
  <HelmetProvider>
    <BrowserRouter>
      <Provider template={AlertTemplate} {...options}>
        <App />
      </Provider>
    </BrowserRouter>
  </HelmetProvider>,
  document.getElementById("root")
);

// If you want to enable client cache, register instead.
serviceWorker.unregister();

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
